# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 11:49:32 2015

@author: mbbxkeh2
"""
from __future__ import absolute_import, division, print_function
import matplotlib.pyplot as plt
import numpy as np
import cv2
import os
import platform
import sys
#memory related imports
import gc

import shutil
#Minimal Example

def dir_list2(dir_name, *args):
    """Returns a list of all files in a path, not looking into folders"""
    fileList = []
    for file in os.listdir(dir_name):
        dirfile = os.path.join(dir_name, file)
        if os.path.isfile(dirfile):
            if len(args) == 0:
                fileList.append(dirfile)
            else:
                if os.path.splitext(dirfile)[1][1:] in args:
                    fileList.append(dirfile)
        '''
        elif os.path.isdir(dirfile):
            print "Accessing directory:", dirfile
            fileList += dir_list2(dirfile, *args)
        '''
    return fileList
    
    
    
if __name__ == '__main__':
        path=os.getcwd()
        #assuming Windows path
        path=path+'\\Images'
        
        fileList=dir_list2(path)
        fileType='.png'
        lowerThreshold=80
        
        loopCounter=-1
        
        for fileName in fileList:
            loopCounter += 1
            #read image
            if (fileName[-4:len(fileName)] == fileType):
                img =cv2.imread(fileName,0)
            
            edges = cv2.Canny(img,lowerThreshold,lowerThreshold*2)
            dispedges=edges.copy()

            contours, hierarchy = cv2.findContours(edges,cv2.cv.CV_RETR_LIST,cv2.cv.CV_CHAIN_APPROX_NONE) #cv2.cv.CV_CHAIN_APPROX_NONE or cv2.cv.CV_CHAIN_APPROX_SIMPLE
            
            #Select longest contour as this should be the capsule
            lengthC=0
            ID=-1
            idCounter=-1
            for x in contours:
                idCounter=idCounter+1 
                if len(x) > lengthC:
                    lengthC=len(x)
                    ID=idCounter
            
            if ID != -1:
                    cnt = contours[ID]
                    cntFull=cnt.copy()
                    
                    #approximate the contour, where epsilon is the distance to 
                    #the original contour
                    cnt = cv2.approxPolyDP(cnt, epsilon=1, closed=True)
                    
                    #add the first point as the last point, to ensure it is closed
                    lenCnt=len(cnt)
                    cnt= np.append(cnt, [[cnt[0][0][0], cnt[0][0][1]]]) #[[cnt[0][0][0],cnt[0][0][1]]])
                    cnt=np.reshape(cnt, (lenCnt+1,1, 2))
                    
                    lenCntFull=len(cntFull)
                    cntFull= np.append(cntFull, [[cntFull[0][0][0], cntFull[0][0][1]]]) #[[cnt[0][0][0],cnt[0][0][1]]])
                    cntFull=np.reshape(cntFull, (lenCntFull+1,1, 2))
                    
                    M = cv2.moments(cnt)
                    MFull = cv2.moments(cntFull)
                    print('Area = %.2f \t Area of full contour= %.2f' %(M['m00'], MFull['m00']))
                    
                    
                    #==========================================================
                    #Saving images of contour to file
                    #==========================================================
                    #find bounding rectangle of countour
                    x,y,w,h = cv2.boundingRect(cnt)
                    cv2.rectangle(dispedges,(x,y),(x+w,y+h),(255,255,255),2) 

                    
                    f2=plt.figure()
                    plt.subplot(121),plt.imshow(img,cmap = 'gray')
                    plt.title('Original Image'), plt.xticks([]), plt.yticks([])
                    plt.subplot(122),plt.imshow(dispedges,cmap = 'gray')
                    plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
                    
                    plt.show()
                    filesavepath='ImageAndContour_'+str(loopCounter)+'.png'
                    plt.savefig(filesavepath, dpi=300,bbox_inches='tight')
                    plt.close(f2)                    
                    
                    f4=plt.figure()
                    xPlot=[]; yPlot=[]
                    xfPlot=[]; yfPlot=[]
                    cntFull
                    for gg in range(len(cnt)):
                        xPlot.append(cnt[gg][0][0])
                        yPlot.append(cnt[gg][0][1])
                    for hh in range(len(cntFull)):
                        xfPlot.append(cntFull[hh][0][0])
                        yfPlot.append(cntFull[hh][0][1])
                    plt.plot(xfPlot, yfPlot, 's', color='#1b9e77', label='Full Contour', markersize=2)
                    plt.plot(xPlot, yPlot, 'o', color='#7570b3', label='approxPolyDP Contour' ,  markersize=7)
            
                    plt.legend(loc=2, fontsize=6)
                    plt.show()
                    filesavepath='FoundContours_'+str(loopCounter)+'.png'
                    plt.savefig(filesavepath, dpi=300,bbox_inches='tight')
                    plt.close(f4)
                    
                    
        
                    
                    